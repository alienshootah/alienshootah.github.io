function myMenu(x) {
    x.classList.toggle("change");
}

$('.one-time').slick({
    dots: false,
    arrows: false,
    infinite: true,
    speed: 900,
    slidesToShow: 1,
    adaptiveHeight: true,
    autoplay: false,
    autoplaySpeed: 5000,
});