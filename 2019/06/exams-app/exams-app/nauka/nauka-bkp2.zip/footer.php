<footer>
    <div class="content">
        <div class="row footer-body">
            <div class="col-4">
                <a href="#" class="header-logo footer-logo"></a>
                <p class="footer-descr">Edukacja na pierwszym miejscu</p>
            </div>
            <div class="col-8 text-right">
                <ul class="footer-list">
                    <li class="footer-item"><a href="#" class="footer-link">MÓJ PROFIL</a></li>
                    <li class="footer-item"><a href="#" class="footer-link">NAUKA</a></li>
                    <li class="footer-item"><a href="#" class="footer-link">EGZAMINY</a></li>
                </ul>
                <p class="footer-copy">Wszelkie prawa zastrzeżone. 2019 Edukacja.pl</p>
            </div>
        </div>
    </div>
</footer>