<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Egzamin 1 - Nauka</title>
    <link rel="stylesheet" href="bootstrap-4/css/bootstrap.min.css">
    <link rel="stylesheet/less" href="css/style.less">
    <link rel="stylesheet/less" href="css/media.less">
</head>
<body>
    <div class="container-fluid">
    <?php include("header.php"); ?>
        <main class="pages">
            <div class="content">
                <div class="row pages-body">
                    <div class="col-12">
                        <h1 class="main-title">Egzamin</h1>
                    </div>
                </div>
            </div>
        </main>
        <section class="spec">
            <div class="content">
                <div class="row spec-body">
                    <div class="col-12">
                        <h2 class="spec-title">Wybierz specjalizacje</h2>
                        <ul class="radio-group spec-list">
                            <li class="spec-item radio">
                                <div class="spec-item_wrap">
                                    Instalacyjna w zakresie sieci, instalacji i urządzeń elektrycznych i elektroenergetycznych (IE)
                                    <div class="spec-right">
                                        <span class="spec-plus"></span>
                                        <span class="spec-active">Wybrano</span> 
                                        <span class="spec-pass">Wybierz</span> 
                                    </div>
                                </div>
                            </li>
                            <li class="spec-item radio selected">
                                <div class="spec-item_wrap">
                                    Instalacyjna w zakresie sieci, instalacji i urządzeń telekumunikacyjnych
                                    <div class="spec-right">
                                        <span class="spec-plus"></span>
                                        <span class="spec-active">Wybrano</span> 
                                        <span class="spec-pass">Wybierz</span> 
                                    </div>
                                </div>
                            </li>
                            <li class="spec-item radio">
                                <div class="spec-item_wrap">
                                    Inżynieria wyburzeniowa
                                    <div class="spec-right">
                                        <span class="spec-plus"></span>
                                        <span class="spec-active">Wybrano</span> 
                                        <span class="spec-pass">Wybierz</span> 
                                    </div>
                                </div>
                            </li>
                            <li class="spec-item radio">
                                <div class="spec-item_wrap">
                                    Inżynieria kolejowa (sterowanie ruchem kolejowym)
                                    <div class="spec-right">
                                        <span class="spec-plus"></span>
                                        <span class="spec-active">Wybrano</span> 
                                        <span class="spec-pass">Wybierz</span> 
                                    </div>
                                </div>
                            </li>
                            <li class="spec-item radio">
                                <div class="spec-item_wrap spec-item_wrap-end">
                                    Inżynieria mostowa
                                    <div class="spec-right">
                                        <span class="spec-plus"></span>
                                        <span class="spec-active">Wybrano</span> 
                                        <span class="spec-pass">Wybierz</span> 
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <section class="spec">
            <div class="content">
                <div class="row spec-body">
                    <div class="col-12">
                        <h2 class="spec-title">Wybierz typ uprawnień</h2>
                        <ul class="radio-group spec-list">
                            <li class="spec-item radio">
                                <div class="spec-item_wrap">
                                    Projektowa bez ograniczeń
                                    <div class="spec-right">
                                        <span class="spec-plus"></span>
                                        <span class="spec-active">Wybrano</span> 
                                        <span class="spec-pass">Wybierz</span> 
                                    </div>
                                </div>
                            </li>
                            <li class="spec-item radio">
                                <div class="spec-item_wrap">
                                    Projektowe ograniczone
                                    <div class="spec-right">
                                        <span class="spec-plus"></span>
                                        <span class="spec-active">Wybrano</span> 
                                        <span class="spec-pass">Wybierz</span> 
                                    </div>
                                </div>
                            </li>
                            <li class="spec-item radio">
                                <div class="spec-item_wrap">
                                    Wykonawcze bez ograniczeń
                                    <div class="spec-right">
                                        <span class="spec-plus"></span>
                                        <span class="spec-active">Wybrano</span> 
                                        <span class="spec-pass">Wybierz</span> 
                                    </div>
                                </div>
                            </li>
                            <li class="spec-item radio">
                                <div class="spec-item_wrap">
                                    Wykonawcze ograniczone
                                    <div class="spec-right">
                                        <span class="spec-plus"></span>
                                        <span class="spec-active">Wybrano</span> 
                                        <span class="spec-pass">Wybierz</span> 
                                    </div>
                                </div>
                            </li>
                            <li class="spec-item radio">
                                <div class="spec-item_wrap spec-item_wrap-end">
                                    Wykonawcze i projektowe bez ograniczeń
                                    <div class="spec-right">
                                        <span class="spec-plus"></span>
                                        <span class="spec-active">Wybrano</span> 
                                        <span class="spec-pass">Wybierz</span> 
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <div class="spec-end text-right">
            <div class="content">
                <div class="spec-buttons">
                    <button class="end-btn"> <span class="end-arrow end-arrow-left"></span> Wróć</button>
                    <button class="end-btn end-btn-reverse">Dalej <span class="end-arrow end-arrow-right"></span></button>  
                </div>
            </div>
        </div>
    </div>
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="bootstrap-4/js/bootstrap.min.js"></script>
    <script src="js/less.min.js"></script>
    <script src="js/apps.js"></script>
</body>
</html>