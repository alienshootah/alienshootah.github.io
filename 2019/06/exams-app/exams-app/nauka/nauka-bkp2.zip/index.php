<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Nauka</title>
    <link rel="stylesheet" href="bootstrap-4/css/bootstrap.min.css">
    <link rel="stylesheet/less" href="css/style.less">
    <link rel="stylesheet/less" href="css/media.less">
</head>
<body>
    <div class="container-fluid">
        <?php include("header.php"); ?>
        <main>
            <div class="content">
                <div class="main-body">
                    <div class="row">
                        <div class="col-6">
                            <h1 class="main-title">Nauka</h1>
                            <p class="main-descr">
                                <span class="main-descr_text">Specjalizacja</span>
                                Instalacyjna w zakresie sieci, instalacji i urządzeń elektrycznych
                            </p>
                            <p class="main-descr">
                                <span class="main-descr_text">Typ uprawnień</span>
                                Projektowanie ograniczone
                            </p>
                        </div>
                        <div class="col-6">
                            <ul class="line">
                                <li class="line-item">
                                    <span class="main-descr_text">Poster</span>
                                    <div class="line-body">
                                        <div class="line-visual line-visual-red">78%</div>
                                    </div>
                                </li>
                                <li class="line-item">
                                    <span class="main-descr_text">Wynik</span>
                                    <div class="line-body">
                                        <div class="line-visual line-visual-green">28%</div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <ul class="half">
                        <li class="half-item">
                            <span class="main-descr_text">Ilość pytań</span>
                            <span class="half-number half-number-blue">12 / 24</span>
                        </li>
                        <li class="half-item">
                            <span class="main-descr_text">Poprawne odpowiedzi</span>
                            <span class="half-number half-number-green">10</span>
                        </li>
                        <li class="half-item">
                            <span class="main-descr_text">Błędne odpowiedzi</span>
                            <span class="half-number half-number-red">5</span>
                        </li>
                    </ul>
                    <p class="text-center main-question">13. Dlaczego nie można budować piwnic na podmokłym terenie?</p>
                    <form method="post" action="send.php">
                        <div class="radio-group question">
                            <div class='question-item radio selected' data-value="One">
                                <span class="question-lett">A</span>
                                Bo nie można i tyle<br>
                                w temacie proszę<br>
                                waści pana godnego
                            </div>
                            <div class='question-item radio' data-value="Two">
                                <span class="question-lett">B</span>
                                Panie, bo się to przeca<br>
                                zapadnie i co wtedy<br>
                                będzie, tragedia panie
                            </div>
                            <div class='question-item radio' data-value="Three">
                                <span class="question-lett">C</span>
                                Przecież to nie ma <br>
                                sensu aby budować <br>
                                na wodzie typie
                            </div>
                        </div>
                    </form>
                    <div class="end">
                        <div class="row end-body">
                            <div class="col-2">
                                <button class="end-btn"> <span class="end-arrow end-arrow-left"></span> Wróć</button>
                            </div>
                            <div class="col-8">
                                <ul class="end-list">
                                    <li class="end-item">
                                        <div class="dropdown">
                                            <button type="button" class="end-title" data-toggle="dropdown">
                                                <span class="end-icon end-icon-one"></span>
                                                Podpowiedź rysunkowa
                                            </button>
                                            <div class="dropdown-menu end-hide">
                                                <span class="end-image"></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="end-item">
                                        <div class="dropdown">
                                            <button type="button" class="end-title" data-toggle="dropdown">
                                                <span class="end-icon end-icon-two"></span>
                                                Podpowiedź tekstowa
                                            </button>
                                            <div class="dropdown-menu end-hide">
                                                <p class="text-center end-text">
                                                    Lorem ipsum dolorem semit emt<br>
                                                    dolorem semit dolorem valorem<br>
                                                    semit dolorem volorem semit don<br>
                                                    valorem semit lorem semit<br>
                                                    noker soker boasd dore kor.
                                                </p>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-2 text-right">
                                <button class="end-btn end-btn-reverse">
                                    Dalej <span class="end-arrow end-arrow-right"></span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="bootstrap-4/js/bootstrap.min.js"></script>
    <script src="js/less.min.js"></script>
    <script src="js/apps.js"></script>
</body>
</html>