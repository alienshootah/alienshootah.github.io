// Иконка меню анимация на 768 пикселей
function myFun(x) {
  x.classList.toggle("change");
}

$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
  });